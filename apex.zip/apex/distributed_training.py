import torch
from ignite.engine import Engine, Events
from torch.nn import MSELoss
from ignite.contrib.handlers.param_scheduler import CosineAnnealingScheduler
from apex import amp
import argparse
import os
from apex.parallel import DistributedDataParallel
import apex
from apex.optimizers import FusedLAMB
from model import Net
from filedataset import OptionDataSet
from ignite.metrics import MeanAbsoluteError
import ignite
import shutil
import torch.distributed as dist

parser = argparse.ArgumentParser()
parser.add_argument("--local_rank", default=0, type=int)
parser.add_argument("--path", default=None)
parser.add_argument("--mae_improv_tol", default=0.002, type=float)
args = parser.parse_args()

args.distributed = False
if 'WORLD_SIZE' in os.environ:
    args.distributed = int(os.environ['WORLD_SIZE']) > 1

if args.distributed:
    torch.cuda.set_device(args.local_rank)
    torch.distributed.init_process_group(backend='nccl',
                                         init_method='env://')

torch.backends.cudnn.benchmark = True

trn_dataset = OptionDataSet(filename='./trn.pth',
                            rank=dist.get_rank(),
                            world_size=int(os.environ['WORLD_SIZE']))
trn_dataset = torch.utils.data.DataLoader(trn_dataset,
                                          batch_size=1024,
                                          shuffle=True,
                                          num_workers=0)

val_dataset = OptionDataSet(filename='./val.pth',
                            rank=dist.get_rank(),
                            world_size=int(os.environ['WORLD_SIZE']))
val_dataset = torch.utils.data.DataLoader(val_dataset,
                                          batch_size=1024,
                                          shuffle=False,
                                          num_workers=0)

model = Net().cuda()
optimizer = FusedLAMB(model.parameters(), lr=1e-3)
loss_fn = MSELoss()


model = apex.parallel.convert_syncbn_model(model, channel_last=True)
model, optimizer = amp.initialize(model, optimizer, opt_level='O1')


best_mae = 100000

if args.path is not None:
    def resume():
        global best_mae
        checkpoint = torch.load(args.path)
        best_mae = checkpoint['best_mae']
        model.load_state_dict(checkpoint['state_dict'])
        amp.load_state_dict(checkpoint['amp'])
        optimizer.load_state_dict(checkpoint['optimizer'])
    resume()


if args.distributed:
    model = DistributedDataParallel(model)
    

def train_update(engine, batch):
    model.train()
    optimizer.zero_grad()
    x = batch[0]
    y = batch[1]
    y_pred = model(x)
    loss = loss_fn(y, y_pred[:, 0])
    with amp.scale_loss(loss, optimizer) as scaled_loss:
        scaled_loss.backward()
    optimizer.step()
    return loss.item()

trainer = Engine(train_update)
log_interval = 500

scheduler = CosineAnnealingScheduler(optimizer, 'lr', 1e-5, 5e-6,
                                     len(trn_dataset),
                                     start_value_mult=0.999, end_value_mult=0.999,
                                     save_history=False
                                     )
trainer.add_event_handler(Events.ITERATION_STARTED, scheduler)


def save_checkpoint(state, is_best, filename='checkpoint.pth.tar'):
    torch.save(state, filename)
    if is_best:
        shutil.copyfile(filename, 'check_points/model_best.pth.tar')


@trainer.on(Events.ITERATION_COMPLETED)
def log_training_loss(engine):
    iter = (engine.state.iteration - 1) % len(trn_dataset) + 1
    if iter % log_interval == 0:
        print('loss', engine.state.output, 'iter', engine.state.iteration,
              'lr', scheduler.get_param())


metric = MeanAbsoluteError()
loss_m = ignite.metrics.Loss(loss_fn)

# run eval at one process only
def eval_update(engine, batch):
    model.eval()
    x = batch[0]
    y = batch[1]
    y_pred = model(x)
    return y, y_pred[:, 0]
evaluator = Engine(eval_update)
metric.attach(evaluator, "MAE")
loss_m.attach(evaluator, "loss")
        
@trainer.on(Events.EPOCH_COMPLETED)
def log_evalnumber(engine):
    global best_mae
    mae_improv_tol = args.mae_improv_tol  # default 0.002 or 0.2% improvement
    evaluator.run(val_dataset, max_epochs=1)
    metrics = evaluator.state.metrics
    average_tensor = torch.tensor([metrics['MAE'], metrics['loss']]).cuda()
    torch.distributed.reduce(average_tensor, 0, op=torch.distributed.ReduceOp.SUM)
    torch.distributed.broadcast(average_tensor, 0)
    average_tensor = average_tensor/int(os.environ['WORLD_SIZE'])

    mae = average_tensor[0].item()
    is_best = False
    if (1 - mae / best_mae) >= mae_improv_tol or \
            (engine.state.epoch == engine.state.max_epochs and
             mae < best_mae):
        best_mae = mae
        is_best = True

    # print("RANK {}   Val Results - Epoch: {}  Avg MAE: {:.5f} loss: {:.5f} BEST MAE: {:.5f}"
    #      .format(dist.get_rank(), trainer.state.epoch, metrics['MAE'], metrics['loss'], best_mae))

    if dist.get_rank() == 0:
        print('Epoch {}/{}'.format(engine.state.epoch, engine.state.max_epochs))
        print('Best MAE Improvement Tolerance for checkpointing: {}%'.format(100 * mae_improv_tol))
        print("RANK {} AVG {} NGPUs, best-mae: {:.5f} mae: {:.5f} loss: {:.5f}".format(
            dist.get_rank(),
            int(os.environ['WORLD_SIZE']),
            best_mae,
            average_tensor[0].item(),
            average_tensor[1].item()))
        fname = 'check_points/current_pth.tar'
        if is_best:
            save_checkpoint({'epoch': trainer.state.epoch,
                             'state_dict': model.module.state_dict(),
                             'best_mae': best_mae,
                             'optimizer': optimizer.state_dict(),
                             'amp': amp.state_dict()
                             }, is_best,
                            filename=fname)
        inputs = torch.tensor([[110.0, 100.0, 120.0, 0.35, 0.1, 0.05]]).cuda()
        res = model(inputs)
        print('test one example:', res.item())

trainer.run(trn_dataset, max_epochs=2000)